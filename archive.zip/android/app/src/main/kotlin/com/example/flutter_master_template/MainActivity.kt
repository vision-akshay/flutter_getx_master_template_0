package com.example.flutter_master_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
